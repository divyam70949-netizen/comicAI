PHASE WISE DOCUMENT - COMIC CRAFT

Project: COMIC CRAFT – AI COMIC STORY USING GEMINI MODEL

Structure:
1. Brainstorming & Ideation Phase
2. Requirement Analysis Phase
3. Project Design Phase
4. Project Planning Phase
5. Project Development Phase
6. Project Testing Phase
7. Project Documentation Phase
8. Project Demonstration Phase

Each phase has its own folder and its own PDF document.
Student-specific fields are left available for later input.
Marks, percentages, grades and evaluation scores are excluded.
